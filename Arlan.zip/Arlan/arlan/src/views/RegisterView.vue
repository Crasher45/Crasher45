<script setup>

</script>

<template>
    <h1>Registrati page</h1>
</template>

<style scoped>
    h1 {
        color: green;
        
    }
</style>