<script>
import { ref } from 'vue';

export default {
    components: {},
    setup(){
        const email = ref("");
        const password = ref("");
        const error= ref("");
        const login=async() =>{
        const res=await fetch(
            "http://89.168.27.59:8080/api/auth/login", 
            {

        
                method: "POST",
                headers:{
                     "Content-Type": "application/json",

                },
                body: JSON.stringify({
                    email: email.value,
                    password: password.value

                })
            
            
            }
        
        );
        const arlan = await res.json();
        console.log(arlan);
        if(res.status !== 200)
        {
            error.value = "An error occurred"
        }
    }
        


        /*const login = () => {
            console.log(email.value);
            console.log(password.value);

        }*/

        return{
            email:email,
            password:password,
            login:login,
            error: error,
        }
    },

}

</script>

<template>
    <div>
    <h1>Login page</h1>
    <form>
        <label>Email</label>
        <input type="text" placeholder="email" v-model="email"/>
        <label>Password</label>
        <input type="password" placeholder="password" v-model="password"/>
        <button type="button" @click="login"> Login </button>
        <div v-if="error != ''">{{ error }}</div>
    </form>
    </div>
</template>

<style scoped>
    h1 {
        color: red;
    }
    div{
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    form {
        max-width: 500px;
        display: flex;
        flex-direction: column;
    }

    form >input{
        margin-top: 1rem;
    }
    button{
        margin-top: 1rem;
    }
</style>
