<template>
    <div>
        <Header></Header>
        <div v-if="viewBook">
            <h1>{{ titolo }}</h1>
            <p>{{ autore }} {{  num }}</p>
        </div>
        <div v-for="book in books">
            <h1>{{ book.title }}</h1>
            <p>{{ book.author }} </p>
            <a :href="book.link">Scopri di piu</a>
        </div>
        <button @click="num++">Cliccami!</button>
        <button @click="cambiaTitolo">Cambia titolo</button>
        <button @click="toggleBook">Nascondi/visualizza</button>
        <input v-model="num" type="number" placeholder="Inserisci numero">
        <p> {{ num }}</p>
        
    </div>

    
    <input type="number" v-model="op1" placeholder="Inserisci il primo numero">
    <input type="number" v-model="op2" placeholder="Inserisci il secondo numero">
    <p>Somma  {{ ris }}</p>
</template>

<script setup>
import Header from "../components/Header.vue";
import { ref, computed } from "vue";
let viewBook=ref(true);
const titolo = ref("Promessi sposi");
const autore = ref("Alessandro Manzoni");
const num=ref(0);
const op1=ref(0);
const op2=ref(0);
//dentro al computed si inserisce la funzione
const ris=computed(() => {return op1.value+op2.value})
const books=ref([
    {title: "Promessi Sposi", author: "Alessandro Manzoni", link:"https://it.wikipedia.org/wiki/I_promessi_sposi"},
    {title: "Divina commedia", author: "Dante", link:"https://it.wikipedia.org/wiki/Divina_Commedia"},
    {title: "Guerra e pace", author: "Tolstoj", link:"https://it.wikipedia.org/wiki/Guerra_e_pace"}
])
const cambiaTitolo = () => {
    titolo.value = "Il conte di Montecristo";

}    
const toggleBook =()=>{
    viewBook.value=!viewBook.value;
    console.log(viewBook);

} 
    


</script>

<style  scoped>

</style>